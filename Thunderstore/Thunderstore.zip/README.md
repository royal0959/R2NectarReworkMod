# Growth Nectar Rework
(https://github.com/royal0959/R2NectarReworkMod/blob/main/new_stats.png)

All non-mechanical allies gain +200% damage and +150% health for each stack, while also being granted a random Tier 1 elite buff

Idea & mod icon art by colonel