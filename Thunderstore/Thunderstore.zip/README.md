# Growth Nectar Rework
https://github.com/royal0959/R2NectarReworkMod/blob/main/new_stats.png?raw=true

Idea & mod icon art by colonel