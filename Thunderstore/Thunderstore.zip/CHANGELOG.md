## 1.0.25

- Fix F2 debug key being enabled

## 1.0.0

- Release