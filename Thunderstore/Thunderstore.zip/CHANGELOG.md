## 1.1.2

- Embedded new stats in Thunderstore description

## 1.1.1

- Fix allies being buffed way more than are intended to be
- Fix allies buff item being in the loot pool (ops)

## 1.1.0

- Summoned Greater Wisp is now named Guardian Wisp
- Made Guardian Wisp move & attack faster
- Made ally stat boost use a new item instead of using BoostHp & BoostDamage
 
## 1.0.3

- Fix elite allies not being given their elite appearance
- Fix existing allies not being affected by buff after item pick-up

## 1.0.25

- Fix F2 debug key being enabled

## 1.0.0

- Release