# Growth Nectar Rework

Reworks Growth Nectar into Drone Parts for all organic allies. Includes literally everything that's not mechanical so even Gooboos, Alpha Constructs & Happiest Mask spawns can benefit from it